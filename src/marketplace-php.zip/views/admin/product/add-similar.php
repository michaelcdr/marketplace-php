<div class="cabecalho">
    Adicionar produto similar
</div>
<div class="corpo">
    <?php include './views/admin/product/list-similar-products-of-product.php' ?>
</div>
<div class="rodape"></div>