<?php 
    
    namespace infra\interfaces;
    
    interface IStateRepository 
    {
        public function getAll();
    }

?>