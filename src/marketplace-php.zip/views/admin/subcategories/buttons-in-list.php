<div class="row">
    <div class="col-md-6">
        <p>
            <a class="btn btn-warning btn-sm" href="/admin/categoria?id=<?php echo $_GET["id"]; ?>">
                <i class="fa fa-chevron-left"></i> 
            </a>
            <a class="btn btn-dark btn-sm" href="/admin/subcategoria/cadastrar?id=<?php echo $_GET["id"]; ?>">
                <i class="fa fa-plus"></i> Cadastrar subcategoria
            </a>
        </p>
    </div>
</div>