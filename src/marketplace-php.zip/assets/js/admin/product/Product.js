class Product {
    constructor(productId, title, price, description, offer, stock, sku) {
        this.productId = productId;
        this.productId = title;
        this.price = price;
        this.description = description;
        this.offer = offer;
        this.stock = stock;
        this.sku = sku;
    }
}

