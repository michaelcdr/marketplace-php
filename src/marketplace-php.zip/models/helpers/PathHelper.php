<?php

namespace models\helpers;

class PathHelper
{
    private $pathImgProduct = '/assets/img/products/';

    public function getPathImgProduct()
    {
        return $this->pathImgProduct;
    }
}
