<li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" 
        role="button" aria-haspopup="true" aria-expanded="false">Area administrativa
    </a>
    <div class="dropdown-menu bg-dark text-white">
        <a class="dropdown-item" href="/admin/usuario/minhas-compras">
            Minhas Compras <span class="sr-only"></span>
        </a>
        <a class="dropdown-item" href="/admin/produto">
            Produtos <span class="sr-only"></span>  
        </a>
    </div>
</li>