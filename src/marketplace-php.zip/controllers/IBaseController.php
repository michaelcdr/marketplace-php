<?php

    namespace controllers;

    interface IBaseController
    {
        public function proccessRequest() : void;
    }