<script src="/assets/libs/jquery/jquery-3.4.1.min.js"></script>
<script src="/assets/js/extensoesJquery.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="/assets/libs/sidebar/jquery.sidebar.js"></script>
<script src="/assets/libs/sweetAlert2/sweetalert2.min.js"></script>
<script src="/assets/js/sweetAlertHelper.js"></script>
<script src="/assets/js/bs4-extensions.js"></script>