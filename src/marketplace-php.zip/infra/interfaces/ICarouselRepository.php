<?php
    namespace infra\interfaces;

    interface ICarouselRepository 
    {
        public function getAll();
    }
?>