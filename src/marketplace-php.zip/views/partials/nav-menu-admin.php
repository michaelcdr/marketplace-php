<li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Area administrativa</a>
    <div class="dropdown-menu bg-dark text-white">
        <a class="dropdown-item" href="/admin/categoria">
            Categorias <span class="sr-only"></span>
        </a>
        <a class="dropdown-item" href="/admin/vendedor">
            Vendedores <span class="sr-only"></span>
        </a>
        <a class="dropdown-item" href="/admin/produto">
            Produtos <span class="sr-only"></span>
        </a>
        <a class="dropdown-item" href="/admin/usuario">
            Usuários <span class="sr-only"></span>
        </a>
        <a class="dropdown-item" href="/admin/atributo">
            Atributos <span class="sr-only"></span>
        </a>
        <a class="dropdown-item" href="/admin/avaliacoes-pendentes">
            Avaliações <span class="sr-only"></span>
        </a>
    </div>
</li>